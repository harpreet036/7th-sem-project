import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { UserSettings } from '../types/dashboard';

interface SettingsState {
  settings: UserSettings;
  updateSettings: (settings: Partial<UserSettings>) => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      settings: {
        theme: 'dark',
        notifications: true,
        refreshInterval: 5000,
        chartTimespan: 24,
      },
      updateSettings: (newSettings) =>
        set((state) => ({
          settings: { ...state.settings, ...newSettings },
        })),
    }),
    {
      name: 'iot-dashboard-settings',
    }
  )
);