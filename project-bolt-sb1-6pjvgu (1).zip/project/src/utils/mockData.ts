import { SensorData, ChartData, Alert, Device } from '../types/dashboard';
import { subHours } from 'date-fns';

export const generateMockSensorData = (): SensorData[] => [
  {
    id: '1',
    name: 'Temperature',
    value: 23.5,
    unit: '°C',
    status: 'normal',
    timestamp: new Date(),
  },
  {
    id: '2',
    name: 'Humidity',
    value: 45,
    unit: '%',
    status: 'warning',
    timestamp: new Date(),
  },
  {
    id: '3',
    name: 'Pressure',
    value: 1013,
    unit: 'hPa',
    status: 'normal',
    timestamp: new Date(),
  },
  {
    id: '4',
    name: 'CO2',
    value: 800,
    unit: 'ppm',
    status: 'critical',
    timestamp: new Date(),
  },
];

export const generateMockChartData = (): ChartData[] => {
  const data: ChartData[] = [];
  for (let i = 24; i >= 0; i--) {
    data.push({
      timestamp: subHours(new Date(), i).getTime(),
      temperature: 20 + Math.random() * 5,
      humidity: 40 + Math.random() * 20,
      pressure: 1000 + Math.random() * 30,
    });
  }
  return data;
};

export const generateMockAlerts = (): Alert[] => [
  {
    id: '1',
    title: 'High Temperature Alert',
    message: 'Temperature exceeded threshold in Server Room A',
    severity: 'critical',
    timestamp: new Date(),
    acknowledged: false,
  },
  {
    id: '2',
    title: 'Humidity Warning',
    message: 'Humidity levels are above normal in Data Center 2',
    severity: 'warning',
    timestamp: subHours(new Date(), 1),
    acknowledged: false,
  },
  {
    id: '3',
    title: 'System Update',
    message: 'Scheduled maintenance completed successfully',
    severity: 'info',
    timestamp: subHours(new Date(), 2),
    acknowledged: true,
  },
];

export const generateMockDevices = (): Device[] => [
  {
    id: '1',
    name: 'Temperature Sensor A1',
    type: 'Temperature Sensor',
    status: 'online',
    lastPing: new Date(),
    location: 'Server Room A',
  },
  {
    id: '2',
    name: 'Humidity Sensor B2',
    type: 'Humidity Sensor',
    status: 'online',
    lastPing: new Date(),
    location: 'Data Center 2',
  },
  {
    id: '3',
    name: 'Pressure Sensor C3',
    type: 'Pressure Sensor',
    status: 'maintenance',
    lastPing: subHours(new Date(), 1),
    location: 'HVAC System',
  },
  {
    id: '4',
    name: 'CO2 Sensor D4',
    type: 'Gas Sensor',
    status: 'offline',
    lastPing: subHours(new Date(), 2),
    location: 'Office Area',
  },
];