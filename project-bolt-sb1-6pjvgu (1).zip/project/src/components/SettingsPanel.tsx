import React from 'react';
import { Settings } from 'lucide-react';
import { Button } from './Button';
import { UserSettings } from '../types/dashboard';
import { useSettingsStore } from '../store/settingsStore';

export const SettingsPanel: React.FC = () => {
  const { settings, updateSettings } = useSettingsStore();

  return (
    <div className="bg-gray-800 rounded-lg p-6 shadow-lg">
      <div className="flex items-center space-x-2 mb-6">
        <Settings className="w-5 h-5 text-blue-400" />
        <h3 className="text-xl font-semibold text-gray-200">Dashboard Settings</h3>
      </div>
      <div className="space-y-6">
        <div>
          <label className="text-sm font-medium text-gray-300 block mb-2">
            Theme
          </label>
          <select
            value={settings.theme}
            onChange={(e) => updateSettings({ theme: e.target.value as UserSettings['theme'] })}
            className="w-full bg-gray-700 border-gray-600 rounded-lg text-white px-4 py-2"
          >
            <option value="dark">Dark</option>
            <option value="darker">Darker</option>
          </select>
        </div>
        
        <div>
          <label className="text-sm font-medium text-gray-300 block mb-2">
            Data Refresh Interval
          </label>
          <select
            value={settings.refreshInterval}
            onChange={(e) => updateSettings({ refreshInterval: Number(e.target.value) })}
            className="w-full bg-gray-700 border-gray-600 rounded-lg text-white px-4 py-2"
          >
            <option value="1000">1 second</option>
            <option value="5000">5 seconds</option>
            <option value="10000">10 seconds</option>
            <option value="30000">30 seconds</option>
          </select>
        </div>

        <div>
          <label className="text-sm font-medium text-gray-300 block mb-2">
            Chart Timespan
          </label>
          <select
            value={settings.chartTimespan}
            onChange={(e) => updateSettings({ chartTimespan: Number(e.target.value) })}
            className="w-full bg-gray-700 border-gray-600 rounded-lg text-white px-4 py-2"
          >
            <option value="1">Last hour</option>
            <option value="6">Last 6 hours</option>
            <option value="12">Last 12 hours</option>
            <option value="24">Last 24 hours</option>
          </select>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-gray-300">
            Enable Notifications
          </span>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.notifications}
              onChange={(e) => updateSettings({ notifications: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-800 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>
      </div>
    </div>
  );
};