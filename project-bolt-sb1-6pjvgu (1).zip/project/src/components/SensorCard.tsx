import React from 'react';
import { SensorData } from '../types/dashboard';
import { Thermometer, Droplets, Gauge, Factory } from 'lucide-react';

const icons = {
  Temperature: Thermometer,
  Humidity: Droplets,
  Pressure: Gauge,
  CO2: Factory,
};

interface SensorCardProps {
  sensor: SensorData;
}

export const SensorCard: React.FC<SensorCardProps> = ({ sensor }) => {
  const Icon = icons[sensor.name as keyof typeof icons];
  
  const statusColors = {
    normal: 'bg-green-500',
    warning: 'bg-yellow-500',
    critical: 'bg-red-500',
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Icon className="w-6 h-6 text-blue-400" />
          <h3 className="text-lg font-semibold text-gray-200">{sensor.name}</h3>
        </div>
        <div className={`w-3 h-3 rounded-full ${statusColors[sensor.status]}`} />
      </div>
      <div className="flex items-baseline space-x-2">
        <span className="text-3xl font-bold text-white">{sensor.value}</span>
        <span className="text-lg text-gray-400">{sensor.unit}</span>
      </div>
      <p className="text-sm text-gray-400 mt-2">
        Last updated: {sensor.timestamp.toLocaleTimeString()}
      </p>
    </div>
  );
};