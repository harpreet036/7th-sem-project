import { Wifi, WifiOff, Wrench } from 'lucide-react';
import { Device } from '../../types/dashboard';

interface DeviceStatusIconProps {
  status: Device['status'];
  className?: string;
}

export const DeviceStatusIcon: React.FC<DeviceStatusIconProps> = ({ status, className = "w-4 h-4" }) => {
  switch (status) {
    case 'online':
      return <Wifi className={`${className} text-green-400`} />;
    case 'offline':
      return <WifiOff className={`${className} text-red-400`} />;
    case 'maintenance':
      return <Wrench className={`${className} text-yellow-400`} />;
  }
};