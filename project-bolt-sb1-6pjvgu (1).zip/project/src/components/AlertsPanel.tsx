import React from 'react';
import { Bell, CheckCircle } from 'lucide-react';
import { Alert } from '../types/dashboard';
import { Button } from './Button';

interface AlertsPanelProps {
  alerts: Alert[];
  onAcknowledge: (id: string) => void;
}

export const AlertsPanel: React.FC<AlertsPanelProps> = ({ alerts, onAcknowledge }) => {
  return (
    <div className="bg-gray-800 rounded-lg p-6 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Bell className="w-5 h-5 text-blue-400" />
          <h3 className="text-xl font-semibold text-gray-200">Active Alerts</h3>
        </div>
        <span className="px-3 py-1 bg-gray-700 rounded-full text-sm text-gray-300">
          {alerts.length} alerts
        </span>
      </div>
      <div className="space-y-4 max-h-[400px] overflow-y-auto">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className="bg-gray-700 rounded-lg p-4 flex items-start justify-between"
          >
            <div className="space-y-1">
              <h4 className="font-medium text-gray-200">{alert.title}</h4>
              <p className="text-sm text-gray-400">{alert.message}</p>
              <span className="text-xs text-gray-500">
                {alert.timestamp.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <span
                className={`px-2 py-1 rounded-full text-xs ${
                  alert.severity === 'critical'
                    ? 'bg-red-900 text-red-200'
                    : alert.severity === 'warning'
                    ? 'bg-yellow-900 text-yellow-200'
                    : 'bg-blue-900 text-blue-200'
                }`}
              >
                {alert.severity}
              </span>
              {!alert.acknowledged && (
                <Button
                  variant="secondary"
                  onClick={() => onAcknowledge(alert.id)}
                  className="flex items-center space-x-1 text-sm"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Acknowledge</span>
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};