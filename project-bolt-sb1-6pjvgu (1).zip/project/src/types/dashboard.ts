export interface SensorData {
  id: string;
  name: string;
  value: number;
  unit: string;
  status: 'normal' | 'warning' | 'critical';
  timestamp: Date;
}

export interface ChartData {
  timestamp: number;
  temperature: number;
  humidity: number;
  pressure: number;
}

export interface Alert {
  id: string;
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'critical';
  timestamp: Date;
  acknowledged: boolean;
}

export interface Device {
  id: string;
  name: string;
  type: string;
  status: 'online' | 'offline' | 'maintenance';
  lastPing: Date;
  location: string;
}

export interface UserSettings {
  theme: 'dark' | 'darker';
  notifications: boolean;
  refreshInterval: number;
  chartTimespan: number;
}