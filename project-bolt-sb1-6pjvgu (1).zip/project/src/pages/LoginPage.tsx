import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { Button } from '../components/Button';
import { LogIn } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const login = useAuthStore((state) => state.login);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const success = await login(username, password);
    if (success) {
      navigate('/dashboard');
    } else {
      setError('Invalid credentials. Try admin/admin');
    }
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center px-4 relative"
      style={{
        backgroundImage: `linear-gradient(rgba(17, 24, 39, 0.8), rgba(17, 24, 39, 0.9)), url('https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Animated particles effect */}
      <div className="absolute inset-0 z-0">
        <div className="absolute w-4 h-4 bg-blue-500 rounded-full opacity-20 animate-pulse" style={{ top: '20%', left: '30%' }}></div>
        <div className="absolute w-3 h-3 bg-green-500 rounded-full opacity-20 animate-pulse" style={{ top: '60%', left: '40%' }}></div>
        <div className="absolute w-5 h-5 bg-purple-500 rounded-full opacity-20 animate-pulse" style={{ top: '40%', left: '70%' }}></div>
        <div className="absolute w-4 h-4 bg-yellow-500 rounded-full opacity-20 animate-pulse" style={{ top: '80%', left: '20%' }}></div>
        <div className="absolute w-3 h-3 bg-red-500 rounded-full opacity-20 animate-pulse" style={{ top: '30%', left: '80%' }}></div>
      </div>

      {/* Login form */}
      <div className="max-w-md w-full space-y-8 bg-gray-800/90 p-8 rounded-xl shadow-2xl backdrop-blur-sm relative z-10">
        <div className="text-center">
          <div className="flex justify-center">
            <LogIn className="h-12 w-12 text-blue-500" />
          </div>
          <h2 className="mt-6 text-3xl font-bold text-white">IoT Dashboard Login</h2>
          <p className="mt-2 text-sm text-gray-400">Sign in to access your dashboard</p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <label htmlFor="username" className="text-sm font-medium text-gray-300">
                Username
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="mt-1 block w-full rounded-lg bg-gray-700/50 border-transparent focus:border-blue-500 focus:bg-gray-700 focus:ring-blue-500 text-white px-4 py-2 backdrop-blur-sm"
                required
              />
            </div>
            <div>
              <label htmlFor="password" className="text-sm font-medium text-gray-300">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 block w-full rounded-lg bg-gray-700/50 border-transparent focus:border-blue-500 focus:bg-gray-700 focus:ring-blue-500 text-white px-4 py-2 backdrop-blur-sm"
                required
              />
            </div>
          </div>
          {error && (
            <p className="text-red-500 text-sm text-center">{error}</p>
          )}
          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
          >
            Sign in
          </Button>
        </form>
      </div>
    </div>
  );
};