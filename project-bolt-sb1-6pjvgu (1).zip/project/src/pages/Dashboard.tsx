import { useState, useEffect } from 'react';
import { Navbar } from '../components/Navbar';
import { SensorCard } from '../components/SensorCard';
import { DashboardChart } from '../components/DashboardChart';
import { AlertsPanel } from '../components/AlertsPanel';
import { DevicesPanel } from '../components/DevicesPanel';
import { SettingsPanel } from '../components/SettingsPanel';
import { generateMockSensorData, generateMockChartData, generateMockAlerts, generateMockDevices } from '../utils/mockData';
import { SensorData, ChartData, Alert, Device } from '../types/dashboard';
import { useSettingsStore } from '../store/settingsStore';

export const Dashboard: React.FC = () => {
  const [sensors, setSensors] = useState<SensorData[]>([]);
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const { settings } = useSettingsStore();

  useEffect(() => {
    // Initial data load
    setSensors(generateMockSensorData());
    setChartData(generateMockChartData());
    setAlerts(generateMockAlerts());
    setDevices(generateMockDevices());

    // Simulate real-time updates
    const interval = setInterval(() => {
      setSensors(generateMockSensorData());
      setChartData(prev => {
        const newData = [...prev.slice(1), {
          timestamp: new Date().getTime(),
          temperature: 20 + Math.random() * 5,
          humidity: 40 + Math.random() * 20,
          pressure: 1000 + Math.random() * 30,
        }];
        return newData;
      });
      setDevices(prev => prev.map(device => ({
        ...device,
        lastPing: Math.random() > 0.8 ? new Date() : device.lastPing,
        status: Math.random() > 0.9 ? 'offline' : device.status,
      })));
    }, settings.refreshInterval);

    return () => clearInterval(interval);
  }, [settings.refreshInterval]);

  const handleAcknowledgeAlert = (id: string) => {
    setAlerts(prev =>
      prev.map(alert =>
        alert.id === id ? { ...alert, acknowledged: true } : alert
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {sensors.map(sensor => (
            <SensorCard key={sensor.id} sensor={sensor} />
          ))}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <DashboardChart data={chartData} />
          <AlertsPanel alerts={alerts} onAcknowledge={handleAcknowledgeAlert} />
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DevicesPanel devices={devices} />
          <SettingsPanel />
        </div>
      </main>
    </div>
  );
};